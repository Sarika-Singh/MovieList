package com.example.movieslist.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.movieslist.Adapter.MovieAdapter;
import com.example.movieslist.Api.ApiClient;
import com.example.movieslist.Api.ApiInterface;
import com.example.movieslist.Model.MovieResponse;
import com.example.movieslist.Model.ResultsItem;
import com.example.movieslist.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    MovieAdapter movieAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.movielist);
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(),3,GridLayoutManager.VERTICAL,false));

        boolean flag = hasConnection();
        if (flag) {
            ApiInterface apiService =
                    ApiClient.getClient().create(ApiInterface.class);

            Call<MovieResponse> call = apiService.getMovies("0194225975933603e2ae5267d8814caa");
            call.enqueue(new Callback<MovieResponse>() {

                @Override
                public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                    List<ResultsItem> movies = response.body().getResults();
                    Log.d("RESULT", "onResponse: "+movies);
                    recyclerView.setAdapter(new MovieAdapter(movies, getApplicationContext()));

                }

                @Override
                public void onFailure(Call<MovieResponse> call, Throwable t) {
                    // Log error here since request failed

                }
            });

        }
        else
        {
            Toast.makeText(MainActivity.this, "No Internet", Toast.LENGTH_SHORT).show();
        }


    }

    private boolean hasConnection() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(
                Context.CONNECTIVITY_SERVICE);

        NetworkInfo wifiNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (wifiNetwork != null && wifiNetwork.isConnected()) {
            return true;
        }

        NetworkInfo mobileNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (mobileNetwork != null && mobileNetwork.isConnected()) {
            return true;
        }

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null && activeNetwork.isConnected()) {
            return true;
        }
        if (wifiNetwork == null || !mobileNetwork.isConnected() || !activeNetwork.isAvailable()) {
            return false;
        }

        return false;
    }
}
