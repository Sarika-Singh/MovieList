package com.example.movieslist.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.movieslist.R;

public class MovieDetailActivity extends AppCompatActivity {


    TextView movie_name;
    TextView date;
    TextView lang;
    TextView vote;
    TextView overview;
    ImageView poster;
    ImageView backdrop;
    String image_base="https://image.tmdb.org/t/p/w500/";
    String name;
    String dt;
    String img_path;
    String bd_path;
    String lg;
    int vt;
    String ovr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        Intent i =getIntent();
        name= i.getStringExtra("movie_name");
        img_path=    i.getStringExtra("poster");
        bd_path=  i.getStringExtra("backdrop");
        dt= i.getStringExtra("date");
        lg= i.getStringExtra("lang");
        vt= i.getIntExtra("vote",0);
        ovr= i.getStringExtra("overview");

        movie_name=findViewById(R.id.name);
        date=findViewById(R.id.date);
        lang=findViewById(R.id.lang);
        vote=findViewById(R.id.vote);
        overview=findViewById(R.id.overview);
        poster=findViewById(R.id.poster);
        backdrop=findViewById(R.id.backdrop);


        movie_name.setText(name);
        date.setText(dt);
        lang.setText(lg);
        vote.setText(""+vt);
        overview.setText(ovr);
        Glide.with(getApplicationContext()).load(image_base+img_path).into(poster);
        Glide.with(getApplicationContext()).load(image_base+bd_path).into(backdrop);


    }
}
