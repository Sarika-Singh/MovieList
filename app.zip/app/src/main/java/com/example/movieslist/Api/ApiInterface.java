package com.example.movieslist.Api;

import com.example.movieslist.Model.MovieResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {

@GET("day")
    Call<MovieResponse> getMovies(@Query("api_key") String apiKey);
        }
