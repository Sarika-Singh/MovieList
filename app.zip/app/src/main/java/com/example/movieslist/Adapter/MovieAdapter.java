package com.example.movieslist.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.movieslist.Activity.MovieDetailActivity;
import com.example.movieslist.Activity.ScrollingActivity;
import com.example.movieslist.Model.ResultsItem;
import com.example.movieslist.R;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MyViewHolder> {
List<ResultsItem> movies;
Context context;
String image_base="https://image.tmdb.org/t/p/w500/";

    public MovieAdapter(List<ResultsItem> movies, Context context) {
        this.movies=movies;
        this.context=context;
    }

    @NonNull
    @Override
    public MovieAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        v = LayoutInflater.from(context).inflate(R.layout.movie_card, parent, false);
        MovieAdapter.MyViewHolder holder = new MovieAdapter.MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MovieAdapter.MyViewHolder holder, final int position) {
        holder.movie_name.setText(movies.get(position).getTitle());
//        holder.date.setText(movies.get(position).getReleaseDate());
        String img=image_base+movies.get(position).getPosterPath();












































































        Glide.with(context).load(img).into(holder.imageView);
holder.imageView.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i=new Intent(context, ScrollingActivity.class);
        i.putExtra("movie_name",movies.get(position).getTitle());
        i.putExtra("poster",movies.get(position).getPosterPath());
        i.putExtra("backdrop",movies.get(position).getBackdropPath());
        i.putExtra("date",movies.get(position).getReleaseDate());
        i.putExtra("lang",movies.get(position).getOriginalLanguage());
        i.putExtra("vote",movies.get(position).getVoteCount());
        i.putExtra("overview",movies.get(position).getOverview());
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
//    context.startActivity(new Intent(context, MovieDetailActivity.class));
    }
});
//        holder.overview.setText(movies.get(position).getOverview());
    }

    @Override
    public int getItemCount() {


        return movies.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView movie_name;
        public TextView date;
        public TextView overview;
        public ImageView imageView;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            movie_name=itemView.findViewById(R.id.movie_name);
//            date=itemView.findViewById(R.id.date);
            imageView=itemView.findViewById(R.id.movie_img);
//            overview=itemView.findViewById(R.id.overview);

        }
    }
}
